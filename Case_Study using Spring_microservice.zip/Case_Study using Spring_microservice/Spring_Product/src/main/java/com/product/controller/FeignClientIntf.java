package com.product.controller;

public interface FeignClientIntf {

}
