package com.invoice.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.invoice.model.Order;

@FeignClient(name ="order-service", url = "http://localhost:8031/")
public interface OrderFeignClient {

	@GetMapping("/order/orderById/{id}")
	public Order getOrderById(@PathVariable("id") int orderId);
}