package com.invoice.service;

import java.util.List;

import com.invoice.model.Invoice;

public interface InvoiceServiceIntf {

	void saveInvoice(Invoice model);

	List<Invoice> getAllInvoices();

	Invoice getInvoiceById(int id);

}
